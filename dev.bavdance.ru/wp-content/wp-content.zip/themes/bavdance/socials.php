<div style="overflow: hidden;">
    <a class="block-social" href="<?php echo get_option('vk_link'); ?>">
        <i class="fa fa-vk"></i>
    </a>
    <a class="block-social" href="<?php echo get_option('insta_link'); ?>">
        <i class="fa fa-instagram"></i>
    </a>
    <a class="block-social" href="<?php echo get_option('youtube_link'); ?>">
        <i class="fa fa-youtube"></i>
    </a>
</div>